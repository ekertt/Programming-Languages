#!/bin/bash
echo "digraph E {"
for f in $(find .. -name '*.java'); do

    # Extends
    cat $f | ./remove_comments.sh | perl -0ne 'while (/class\s+(\S+).*?\.*\s+\bextends/sg) {print "$1";}'
    cat $f | ./remove_comments.sh | perl -0ne 'while (/extends\s+(\S+).*?\{.*}/sg) {print " -> $1\n";}'

    # Imports
    var=$(cat $f | ./remove_comments.sh | perl -0ne 'while (/class\s+(\S+).*?/sg) {print "$1";}')
    var2=$(cat $f | ./remove_comments.sh | perl -0ne 'while (/import\s+(\S+)*[;]+/sg) {print "$1\n";}')

    for l in $var2; do
        echo $var "->" ${l##*.} "[arrowhead=dot]"
    done

    # Package
    var3=$(cat $f | ./remove_comments.sh | perl -0ne 'while (/class\s+(\S+).*?/sg) {print "$1";}')
    cat $f | ./remove_comments.sh | perl -0ne 'while (/package\s+(solvers)*[;]+/sg) {print "subgraph cluster_X { label =package $1 \n'$var3' [shape=box]\n}";}'
    cat $f | ./remove_comments.sh | perl -0ne 'while (/package\s+(problem)*[;]+/sg) {print "subgraph cluster_Y { label =package $1 \n'$var3' [shape=box]\n}";}'
done

echo "}"
