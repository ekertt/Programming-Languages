#!/bin/bash

cd ../

if [ $1 ]; then
  find ./ -name '*.java' -exec grep -Hn $1 {} \;
else
  echo 'Script is not called correctly, use it like this: ./find_name.sh <name>'
fi
