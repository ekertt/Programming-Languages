#!/bin/bash

cd ../

if [ $1 ] && [ $2 ]; then
  find ./ -name '*.java' -exec sed "s/$1/$2/g" {} \;
else
  echo 'Script is not called correctly, use it like this: ./rename_name.sh <name-old> <name-new>'
fi
