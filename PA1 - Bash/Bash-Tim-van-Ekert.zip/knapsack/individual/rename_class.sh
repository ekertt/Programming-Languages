#!/bin/bash

cd ../

if [ $1 ] && [ $2 ]; then
  find ./ -name "$1.java" -exec sed -i '' "s/$1/$2/g" {} \;
  mv "$1.java" "$2.java"
else
  echo 'Script is not called correctly, use it like this: ./rename_class.sh <class-old> <class-new>'
fi
