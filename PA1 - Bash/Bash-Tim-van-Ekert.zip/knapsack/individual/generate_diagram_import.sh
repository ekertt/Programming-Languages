#!/bin/bash

echo "digraph E {"
for f in $(find .. -name '*.java'); do
  var=$(cat $f | ./remove_comments.sh | perl -0ne 'while (/class\s+(\S+).*?/sg) {print "$1";}')
  # cat $f | ./remove_comments.sh | perl -0ne 'while (/import\s+(\S+)*[;]+/sg) {print "'$var' -> $1 [arrowhead=dot]\n";}'

  var2=$(cat $f | ./remove_comments.sh | perl -0ne 'while (/import\s+(\S+)*[;]+/sg) {print "$1\n";}')

  for l in $var2; do
    echo $var "->" ${l##*.} "[arrowhead=dot]"
  done
done
echo "}"
