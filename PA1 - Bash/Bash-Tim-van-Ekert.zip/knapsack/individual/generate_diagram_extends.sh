#!/bin/bash

echo "digraph E {"
for f in $(find .. -name '*.java'); do
  cat $f | ./remove_comments.sh | perl -0ne 'while (/class\s+(\S+).*?\.*\s+\bextends/sg) {print "$1";}'
  cat $f | ./remove_comments.sh | perl -0ne 'while (/extends\s+(\S+).*?\{.*}/sg) {print " -> $1\n";}'
done
echo "}"