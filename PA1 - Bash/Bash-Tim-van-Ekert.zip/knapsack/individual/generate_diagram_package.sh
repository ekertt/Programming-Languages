#!/bin/bash

echo "digraph E {"
for f in $(find .. -name '*.java'); do
  var=$(cat $f | ./remove_comments.sh | perl -0ne 'while (/class\s+(\S+).*?/sg) {print "$1";}')
  cat $f | ./remove_comments.sh | perl -0ne 'while (/package\s+(solvers)*[;]+/sg) {print "subgraph cluster_X { label =package $1 \n'$var' [shape=box]\n}";}'
  cat $f | ./remove_comments.sh | perl -0ne 'while (/package\s+(problem)*[;]+/sg) {print "subgraph cluster_Y { label =package $1 \n'$var' [shape=box]\n}";}'
done
echo "}"
